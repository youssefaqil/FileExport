/**
 *	
 *	---------------------
 *	#  Javascript lib/after loading Page
 *	# Creation: 10 2019
 */

 
	(function ($) {
		/**
		 *  After page loading
		 *  ------------------------------------------------
		 */
		$(document).ready(function () {

			/*---------------------------------
			*  Variable  
			*---------------------------------*/

			var openedClassName = 'bnpam-opened',
				closedClassName = 'bnpam-closed';

			/*---------------------------------
			 *  IE Detection
			 *---------------------------------
		
			}*/
			if (Function('/*@cc_on return document.documentMode===9@*/')()) {
				document.documentElement.className += ' bnp-ie9';
			}
			if (Function('/*@cc_on return document.documentMode===10@*/')()) {
				document.documentElement.className += ' bnp-ie10';
			}
			/*---------------------------------
			*  Modal  
			*---------------------------------*/
			$( ".bnp-modal-link" ).click(function() {
				$(".bnp-modal").show();
			});
			$( ".bnp-modal-close" ).click(function() {
				$( ".bnp-modal" ).hide();
			});
			/*---------------------------------
			*  Trigger  
			*---------------------------------*/
			$('html').click(function (e) {
				var element = e.target;
				if ($(element).parents('#bnp-header').length === 0) {
					$("#bnp-topnav").removeClass('active');
					$(".bnp-tools-detail").hide();
					$(".bnp-tools-header").removeClass('active');
					$("#bnp-mainarea").removeClass('active');
					$(".bnp-aside-filter").removeClass('active');
				}
				if ($(element).parents('#bnp-navigation').length === 0) {
					$("#bnp-navigation").removeClass('active');
				}
			});

			$(".bnp-trigger").click(function() {
				//$(this).parent().toggleClass('active');
				$("#bnp-navigation").toggleClass('active');
			});
			$(".bnp-tools-header").click(function () {
				var prt = $(this).parent();
				if ($(this).hasClass('active')) {
					$(".bnp-tools-detail").hide();	
					$(".bnp-tools-header").removeClass('active');		
				} else {
					$(".bnp-tools-detail").hide();	
					$(".bnp-tools-header").removeClass('active');		
					$(".bnp-tools-detail",prt).show();			
					$(this).addClass('active');		
				}
			});
		});

	})(jQuery);
